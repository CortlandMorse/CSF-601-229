Files created with:

./asm tst02.asm tst02.bin
./dis tst02.bin > tst02.dis
./sim tst02.bin tst02.out > tst02.sim
