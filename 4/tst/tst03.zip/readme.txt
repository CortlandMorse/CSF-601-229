Files created with:

./asm tst03.asm tst03.bin
./dis tst03.bin > tst03.dis
./sim tst03.bin tst03.out > tst03.sim
