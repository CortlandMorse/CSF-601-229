Files created with:

./asm tst06.asm tst06.bin
./dis tst06.bin > tst06.dis
./sim tst06.bin tst06.out > tst06.sim
