Files created with:

./asm tst05.asm tst05.bin
./dis tst05.bin > tst05.dis
./sim tst05.bin tst05.out > tst05.sim
