Files created with:

./asm tst04.asm tst04.bin
./dis tst04.bin > tst04.dis
./sim tst04.bin tst04.out > tst04.sim
