Files created with:

./asm tst01.asm tst01.bin
./dis tst01.bin > tst01.dis
./sim tst01.bin tst01.out > tst01.sim
