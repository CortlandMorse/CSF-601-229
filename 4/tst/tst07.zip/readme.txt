Files created with:

./asm tst07.asm tst07.bin
./dis tst07.bin > tst07.dis
./sim tst07.bin tst07.out > tst07.sim
